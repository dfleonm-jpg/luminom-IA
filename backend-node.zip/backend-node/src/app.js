import fs from 'node:fs'
import path from 'node:path'
import express from 'express'
import cors from 'cors'
import apiRoutes from './routes/index.js'
import { DIST_DIR } from './config/env.js'

const app = express()

app.disable('x-powered-by')
app.use(cors())
app.use(express.json({ limit: '50mb' }))

// ---------- API ----------
app.use('/api', apiRoutes)

// ---------- Frontend compilado (PWA) ----------
if (fs.existsSync(DIST_DIR)) {
  app.use(express.static(DIST_DIR))
  app.get('*', (req, res) => {
    const index = path.join(DIST_DIR, 'index.html')
    if (fs.existsSync(index)) return res.sendFile(index)
    res.json({ detail: 'Frontend no compilado. Ejecuta: cd frontend && npm run build' })
  })
} else {
  app.get('/', (req, res) => {
    res.json({ detail: 'Frontend no compilado. Ejecuta: cd frontend && npm run build' })
  })
}

// ---------- Manejo de errores -> { detail } (igual que FastAPI) ----------
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  const status = err.status || err.statusCode || 500
  if (status >= 500) console.error('❌', err)
  res.status(status).json({ detail: err.message || 'Error del servidor' })
})

export default app
